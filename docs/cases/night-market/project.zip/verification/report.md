# TraceGIF verification

Automated checks: **passed**

HTML SHA-256: `d9326a708a5c12d443db8c514b0114c51dc737c411738d9d884fdcd712df1f84`

Visual review: **reviewed** for the HTML hash above.

- Layered skyline, three shops, seven upper windows, striped awnings, ten lanterns, three stalls, four visitors and bicycle match the source geometry, placement and warm night palette. Sky fill is intentional original artwork; margins outside the scene remain transparent.
- Reviewed the actual browser source / drawing / final comparison and checkerboard final plus dark middle captures. Dark source strokes have lower contrast on the dark inspection matte; the light showcase matte is recommended. No geometry, original colors or fonts were substituted.
- The 480 × 320 original and final comparison panels are pixel-identical.
- All four corners of the transparent final browser capture have alpha values [0, 0, 0, 0]. No decorative blue strokes were added.

| Check | Result | Detail |
|---|---|---|
| embedded_resources | passed | [] |
| initial_wait | passed | {'status': 'idle', 'time': 0, 'duration': 10, 'playbackRate': 1.5, 'effectiveDuration': 6.666666666666667, 'exporting': False} |
| speed_changes_without_reset | passed | {'playing': {'status': 'playing', 'time': 2.5578000000715253, 'duration': 10, 'playbackRate': 2, 'effectiveDuration': 5, 'exporting': False}, 'paused': {'status': 'paused', 'time': 2.5616000000238417, 'duration': 10, 'playbackRate': 0.5, 'effectiveDuration': 20, 'exporting': False}} |
| scrubber_seeks_without_global_shortcuts | passed | {'status': 'paused', 'time': 5.01, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| right_starts_without_reset | passed | {'status': 'playing', 'time': 0.204, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| space_pauses_and_resumes | passed | {'status': 'playing', 'time': 0.3428000000119209, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| right_resumes_pause | passed | {'status': 'playing', 'time': 0.4476000000238418, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| r_restarts | passed | {'status': 'playing', 'time': 0.004199999988079071, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| held_key_ignored | passed | {'status': 'paused', 'time': 0.009600000023841858, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| editable_shortcuts_ignored | passed | {'status': 'paused', 'time': 0.009600000023841858, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| screen_button_toggle | passed | {'status': 'playing', 'time': 0.04670000004768372, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| real_time_completion_and_hold | passed | {'status': 'completed', 'time': 10, 'duration': 10, 'playbackRate': 1.5, 'effectiveDuration': 6.666666666666667, 'exporting': False} |
| right_replays_completed | passed | {'status': 'playing', 'time': 0.006, 'duration': 10, 'playbackRate': 1.5, 'effectiveDuration': 6.666666666666667, 'exporting': False} |
| no_network_requests | passed | [] |
| no_browser_errors | passed | [] |

## Screenshots

- [light-start.png](light-start.png): light, 0.00s
- [light-middle.png](light-middle.png): light, 5.00s
- [light-final.png](light-final.png): light, 10.00s
- [dark-start.png](dark-start.png): dark, 0.00s
- [dark-middle.png](dark-middle.png): dark, 5.00s
- [dark-final.png](dark-final.png): dark, 10.00s
- [checker-start.png](checker-start.png): checker, 0.00s
- [checker-middle.png](checker-middle.png): checker, 5.00s
- [checker-final.png](checker-final.png): checker, 10.00s
- [transparent-final.png](transparent-final.png): transparent, 10.00s

The transparent-corner observation does not validate the subject mask or interior white details.
