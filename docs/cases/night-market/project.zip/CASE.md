# Night Market

Rich editorial streetscape for a travel story, event introduction or placemaking presentation.

Native SVG layered scene: skyline and shop structures, windows and awnings, then lanterns, market stalls, visitors and bicycle details.

An original fictional city block, not a real destination, business listing or photo tracing.

Original artwork created for TraceGIF, MIT licensed. No third-party brand, font or user-uploaded image.

Timeline: 10 seconds; default speed: 1.5x. GIF matte: #F6F2E8.

Request: Draw this night market from its skyline and three storefronts to windows, awnings and stalls. Leave lantern ribs, visitors and small street details late, then reveal the original night palette. Export offline HTML, GIF and PNG.

Revision example: Give the lanterns more drawing time, reveal the stalls before the visitors, and export at 1.5x.
