# Camera Exploded

Exploded product anatomy for an editorial launch story or educational presentation.

Native SVG separated optical groups, aperture, sensor board and camera shell; then mechanical details and callout leaders.

A fictional illustrative camera anatomy, not an engineered assembly, repair guide or representation of a real product.

Original artwork created for TraceGIF, MIT licensed. No third-party brand, font or user-uploaded image.

Timeline: 10 seconds; default speed: 1.5x. GIF matte: #F3F5EF.

Request: Introduce this fictional camera through an exploded illustration. Draw lens groups and the body first, then sensor and aperture, then fasteners, surface details and annotation leaders. Keep the original geometry and final colors.

Revision example: Let the lens elements draw one by one before the body and slow the sensor reveal.
