# TraceGIF verification

Automated checks: **passed**

HTML SHA-256: `7513dfb0cf3a4cc8431f88d2e7e330df61caa6555f71fb3b22aec4bfbb10b622`

Visual review: **reviewed** for the HTML hash above.

- Four separated optical groups, aperture, sensor board and camera body match the source proportions, arrangement and blue-green palette. Small contacts, lens highlights, grip texture, annotation leaders and screws remain visible. This is fictional product anatomy, not a mechanically accurate assembly.
- Reviewed the actual browser source / drawing / final comparison and checkerboard final plus dark middle captures. Dark source strokes have lower contrast on the dark inspection matte; the light showcase matte is recommended. No geometry, original colors or fonts were substituted.
- The 480 × 320 original and final comparison panels are pixel-identical.
- All four corners of the transparent final browser capture have alpha values [0, 0, 0, 0]. No decorative blue strokes were added.

| Check | Result | Detail |
|---|---|---|
| embedded_resources | passed | [] |
| initial_wait | passed | {'status': 'idle', 'time': 0, 'duration': 10, 'playbackRate': 1.5, 'effectiveDuration': 6.666666666666667, 'exporting': False} |
| speed_changes_without_reset | passed | {'playing': {'status': 'playing', 'time': 2.5520999999642373, 'duration': 10, 'playbackRate': 2, 'effectiveDuration': 5, 'exporting': False}, 'paused': {'status': 'paused', 'time': 2.5576999999880794, 'duration': 10, 'playbackRate': 0.5, 'effectiveDuration': 20, 'exporting': False}} |
| scrubber_seeks_without_global_shortcuts | passed | {'status': 'paused', 'time': 5.01, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| right_starts_without_reset | passed | {'status': 'playing', 'time': 0.199, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| space_pauses_and_resumes | passed | {'status': 'playing', 'time': 0.3448000000119209, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| right_resumes_pause | passed | {'status': 'playing', 'time': 0.4336000000238418, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| r_restarts | passed | {'status': 'playing', 'time': 0.003, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| held_key_ignored | passed | {'status': 'paused', 'time': 0.006, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| editable_shortcuts_ignored | passed | {'status': 'paused', 'time': 0.006, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| screen_button_toggle | passed | {'status': 'playing', 'time': 0.060400000035762784, 'duration': 10, 'playbackRate': 1, 'effectiveDuration': 10, 'exporting': False} |
| real_time_completion_and_hold | passed | {'status': 'completed', 'time': 10, 'duration': 10, 'playbackRate': 1.5, 'effectiveDuration': 6.666666666666667, 'exporting': False} |
| right_replays_completed | passed | {'status': 'playing', 'time': 0.01410000005364418, 'duration': 10, 'playbackRate': 1.5, 'effectiveDuration': 6.666666666666667, 'exporting': False} |
| no_network_requests | passed | [] |
| no_browser_errors | passed | [] |

## Screenshots

- [light-start.png](light-start.png): light, 0.00s
- [light-middle.png](light-middle.png): light, 5.00s
- [light-final.png](light-final.png): light, 10.00s
- [dark-start.png](dark-start.png): dark, 0.00s
- [dark-middle.png](dark-middle.png): dark, 5.00s
- [dark-final.png](dark-final.png): dark, 10.00s
- [checker-start.png](checker-start.png): checker, 0.00s
- [checker-middle.png](checker-middle.png): checker, 5.00s
- [checker-final.png](checker-final.png): checker, 10.00s
- [transparent-final.png](transparent-final.png): transparent, 10.00s

The transparent-corner observation does not validate the subject mask or interior white details.
