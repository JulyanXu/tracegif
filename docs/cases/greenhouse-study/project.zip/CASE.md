# Greenhouse Study

Dense botanical environment for a garden concept, educational story or architecture portfolio.

Native SVG structural glazing, shelves, individually editable plant silhouettes, foreground specimens and irrigation details.

A fictional greenhouse illustration, not a construction plan, botanical identification guide or engineering simulation.

Original artwork created for TraceGIF, MIT licensed. No third-party brand, font or user-uploaded image.

Timeline: 10 seconds; default speed: 1.5x. GIF matte: #F6F3E7.

Request: Draw the greenhouse envelope and glass ribs first, then its tiered benches and plants. Keep each specimen editable. Finish with pots, irrigation and garden tools before revealing the original greens.

Revision example: Draw the foreground plants later, slow the glass ribs, and create a 720-pixel GIF on a cream background.
